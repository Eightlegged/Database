package com.skcc.eightlegged;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ApplicationTests {

	@Test
	public void contextLoads() {
	}
	
	// Connection Test
	@Autowired
	private DataSource ds;
	
	public void testConn() throws SQLException{
		System.out.println("DataSource : " + ds);
		Connection conn = ds.getConnection();
		System.out.println(conn);
		conn.close();
	}
	
	// SQL Session Test
	@Autowired
	private SqlSessionFactory sqlSession;
	
	@Test
	public void testSession(){
		System.out.println("sqlSession : " + sqlSession);
	}
}

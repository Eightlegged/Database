package com.skcc.eightlegged.MeetingServ.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skcc.eightlegged.MeetingServ.dao.MeetingServDao;
@Service
public class MeetingServService {

	@Autowired
	MeetingServDao meetingServDao;
	
	public List<Map<String, Object>> selectMeetingList() {
		return meetingServDao.selectMeetingList();
	}

}
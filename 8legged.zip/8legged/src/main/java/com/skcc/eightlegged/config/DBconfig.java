package com.skcc.eightlegged.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.validation.annotation.Validated;

@SpringBootApplication
@MapperScan(value="{com.skcc.eightlegged.MeetingServ.mapper}")
public class DBconfig {
	@Bean()
	public SqlSessionFactory sqlSessionFactory(DataSource ds) throws Exception{
		// DataSource를 통한 접속
		SqlSessionFactoryBean sessionBean = new SqlSessionFactoryBean();
		sessionBean.setDataSource(ds);
		
		// 매퍼.xml 리소스 가져오기
		String path = "mapper/base/*.xml";
		Resource[] res = new PathMatchingResourcePatternResolver().getResources(path);
		sessionBean.setMapperLocations(res);
		
		return sessionBean.getObject();
	}
}
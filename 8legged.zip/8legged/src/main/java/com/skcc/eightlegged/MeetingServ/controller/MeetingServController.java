package com.skcc.eightlegged.MeetingServ.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.skcc.eightlegged.MeetingServ.service.MeetingServService;

@RestController
public class MeetingServController {

	@Autowired
	MeetingServService meetingServService;
	
	@RequestMapping("/meetingServ")
	public List<Map<String, Object>> index(){
		List<Map<String, Object>> list = meetingServService.selectMeetingList();
		
		return list;
	}
}